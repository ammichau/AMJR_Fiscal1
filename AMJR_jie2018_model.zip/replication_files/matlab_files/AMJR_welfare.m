function [Vpoor, Vrich, Vtotal] = AMJR_welfare(cpoor, crich, lpoor, lrich)

global M_
global prefs

% pull out parameters that matter for welfare
betta   = M_.params(strmatch('betta',M_.param_names,'exact'));
sgma    = M_.params(strmatch('sgma', M_.param_names,'exact'));
nuR     = M_.params(strmatch('nuR',  M_.param_names,'exact'));
nuP     = M_.params(strmatch('nuP',  M_.param_names,'exact'));
chi     = M_.params(strmatch('chi',  M_.param_names,'exact'));
NR      = M_.params(strmatch('NR',   M_.param_names,'exact'));
NP      = M_.params(strmatch('NP',   M_.param_names,'exact'));


% length of each series and number of simulations
T = size(cpoor,1);
N = size(cpoor,2);


% vector [1, beta, beta^2, beta^3, ...]
discount_factor = 1:1:T;
discount_factor = discount_factor';
discount_factor = betta.^(discount_factor-1);



Vpoor  = 0;
Vrich  = 0;
Vtotal = 0;

for n = 1:N

    cP = cpoor(:,n);
    cR = crich(:,n);
    lP = lpoor(:,n);
    lR = lrich(:,n);

    if strcmp(prefs, 'GHH') == 1
        util_poor = max(cP - chi.*lP.^(1+nuP) / (1+nuP),0.0000001);
        util_rich = max(cR - chi.*lR.^(1+nuR) / (1+nuR),0.0000001);
    elseif strcmp(prefs, 'CD') == 1
        util_poor = cP.^chi .*(1-lP).^(1-chi);
        util_rich = cR.^chi .*(1-lR).^(1-chi);
    end
    
    if abs(sgma-1) < 0.001
        util_poor = log(util_poor);
        util_rich = log(util_rich);
    else
        util_poor = util_poor.^(1-sgma) / (1-sgma);
        util_rich = util_rich.^(1-sgma) / (1-sgma);
    end
    
    
    U_poor = (util_poor'*discount_factor);
    U_rich = (util_rich'*discount_factor);
    U      = NR*U_rich + NP*U_poor;
    
    Vtotal = Vtotal + U;
    Vpoor  = Vpoor + U_poor; 
    Vrich  = Vrich + U_rich;    
    
    
end

    Vtotal = Vtotal / N;
    Vpoor  = Vpoor  / N;
    Vrich  = Vrich  / N;



