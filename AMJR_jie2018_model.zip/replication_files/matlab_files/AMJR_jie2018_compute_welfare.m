%% Michaud and Rothert (2018), "Redistributive Policies and Business Cycles 
% in Emerging Economies", Journal of International Economics
% --------------------------------------------------------------------------------
%% ____________________ REPLICATION FILE FOR: welfare effects ____________________ 
%
%   - calls: 
%       a) Inequality_Targets.xlsx (excel file with data stats 
%                                   for calibration and estimation targets)
%       b) AMJR_compute_ststate.m, 
%                       which in turn calls AMJR_distaxes_ststate.m
%       c) RBC_distaxes_onesector.mod (Dynare file for solving the model 
%                                       and computing model decision rules) 
%       d) GHH_developed_estimation_v3.mat and GHH_emerging_estimation_v3.mat
%           to load the results of SMM estimation from earlier
%       e) AMJR_simulations.m to simulate time series for 
%               consumption and labor
%       f) AMJR_welfare.m to compute \sum_t beta^t U(c_t,l_t) 
%               for t = 1:T, N times, where T and N are big 
%               (T = 1500 and N = 2000 should be enough, we set T = 2000 and N = 2500)
%
%   - to replicate Table proceed as follows:
%       a) run the file 7 times, each time changing line 66
%           by setting countefactual = 1, 2, 3, 4, 5, 11, and 12
%       b)) run the file one more time by setting counterfactual = 0
% -------------------------------------------------------------------------------
%%


%% clear everything
clear all
clc

%% specify paths

% ADD DYNARE PATH
addpath C:\dynare\4.4.3\matlab

% SPECIFY THE MAIN PATH TO THE PROJECT'S PARENT DIRECTORY
mainpath = 'C:\Users\rothert\Dropbox\work\research\ZZZ_PUBLISHED\05_JIE2018_RedistributivePolicies\replication_files\';

ExcelFolder   =  strcat(mainpath,'excel_files');
MatlabFolder  =  strcat(mainpath,'matlab_files');
ResultsFolder =  strcat(mainpath,'results');
DynareFolder  =  mainpath;

%% global variables
global preferences
global country rownr
global deep_parameters
global COUNTRY_MOMENTS
global estimated_parameters
global tauk tauc taul_rich taul_poor
global bgbar sbbar dbar gama
global calibrated_parameters_developed
global calibrated_parameters

global counterfactual
% 0  - emerging benchmark
% 1  - benefits: size
% 2  - benefits: cyclicality
% 3  - benefits: size and cyclicality
% 4  - taxes: size and cyclicality
% 5  - benefits and taxes
% 11 - no z-shocks
% 12 - no R and CS shocks
counterfactual = 0;
%% preferences
% ------------------------------------------------------------------------

preferences = 'GHH';
GHH = 0;
CD  = 0;
SEP = 0;
nuR = 0.60;
nuP = nuR;
% 'GHH' or 'CD' or 'separable'
if  strcmp(preferences , 'GHH') == 1
    GHH = 1;
    chi = 1.45;
elseif strcmp(preferences , 'CD') == 1
    CD  = 1;
    chi = 0.60;
elseif strcmp(preferences , 'separable') == 1
    SEP = 1;
    chi = 1.00;
end
% ------------------------------------------------------------------------


%% country and rownr
% ------------------------------------------------------------------------

if counterfactual == 10
    country = 'developed';
else
    country = 'emerging';
end
rownr = 1*strcmp(country,'emerging') + 2*strcmp(country,'developed');
% ------------------------------------------------------------------------


%% deep parameters
% ------------------------------------------------------------------------
betta  = 0.96;      % discount (annual)
sgma   = 5.0000;    % IES
mug    = 0.00;      % balanced growth rate (annual)
dlta   = 0.04;      % depreciation
alfa   = 0.33;      % capital share
kapa   = 0.01;     % portfolio adj cost private
kapa_g = 0.005;     % portfolio adj cost govt
% world interest rate
if strcmp(preferences , 'CD') == 1
    Rstar = 1.0/betta * exp(mug)^(1-chi*(1-sgma));
else
    Rstar = 1.0/betta * exp(mug)^sgma;
end
deep_parameters = [betta; sgma; mug; dlta; alfa; Rstar; kapa; kapa_g; ...
    GHH; CD; SEP; ...
    nuR; nuP; chi];
% ------------------------------------------------------------------------


%% COUNTRY MOMENTS
% -------------------------------------------------------------------------
cd(ExcelFolder)
data  = xlsread('InequalityTargets.xlsx','data_inputs');

NR          = data(rownr,1);
INCSHARE    = data(rownr,2);
INT_GDP     = data(rownr,3);
SBEN_GDP    = data(rownr,4);
DEBT_GDP    = data(rownr,5);
VATperc     = data(rownr,size(data,2)-3);
PITperc     = data(rownr,size(data,2)-2);
CITperc     = data(rownr,size(data,2)-1);
PITE        = data(rownr,size(data,2));


if counterfactual == 1 || counterfactual == 3
    SBEN_GDP    = data(rownr+1,4);
elseif counterfactual == 4
    VATperc     = data(rownr+1,size(data,2)-3);
    PITperc     = data(rownr+1,size(data,2)-2);
    CITperc     = data(rownr+1,size(data,2)-1);
    PITE        = data(rownr+1,size(data,2));
elseif counterfactual == 5
    SBEN_GDP    = data(rownr+1,4);
    VATperc     = data(rownr+1,size(data,2)-3);
    PITperc     = data(rownr+1,size(data,2)-2);
    CITperc     = data(rownr+1,size(data,2)-1);
    PITE        = data(rownr+1,size(data,2));
end
NP = 1 - NR;

COUNTRY_MOMENTS = [NR; INCSHARE; INT_GDP; SBEN_GDP; DEBT_GDP; NP;...
    VATperc; PITperc; CITperc; PITE];
% -------------------------------------------------------------------------


%% LOAD ESTIMATION RESULTS
% ----------------------------------------------------------
cd(ResultsFolder)
loadfile = strcat(preferences,'_',country,'_estimation_v3.mat');
load(loadfile)
xparam = PARAM_ERRORS(:,1);
loadfile = strcat(preferences,'_',country,'_calibration.mat');
load(loadfile)
calibrated_parameters_emerging = calibrated_parameters;

if strcmp(country , 'emerging') == 1
    loadfile = strcat(preferences,'_developed_estimation_v3.mat');
    load(loadfile)
    PARAM_ERRORS_DEVELOPED = PARAM_ERRORS;
    loadfile = strcat(preferences,'_developed_calibration.mat');
    load(loadfile)
    calibrated_parameters_developed = calibrated_parameters;
    
    if counterfactual == 2 || counterfactual == 3
        indeksy = [3];
    elseif counterfactual == 4
        indeksy = [4];
    elseif counterfactual == 5
        indeksy = [3;4];
    elseif counterfactual == 11  % sig_z = 0
        indeksy = [];
        xparam(6) = 0.0000001;
    elseif counterfactual == 12  % sigr and sigcs = 0
        indeksy = [];
        xparam(7) = 0.0000001;
        xparam(1) = 0.0000000;        
    else
        indeksy = [];
    end
    xparam(indeksy,1) = PARAM_ERRORS_DEVELOPED(indeksy,1);
    
end
calibrated_parameters = calibrated_parameters_emerging;
% ----------------------------------------------------------
% xparam = [%  \eta_cs          1)
%  inv adj cost     2)
%  eta_sb           3)
%  eta_tx           4)
%  rho_z            5)
%  sig_z            6)
%  sig_cs           7)
%  sig_sb           8)
%  sig_tx           9)


eta_cs   = xparam(1);
pphi     = xparam(2);
eta_SB   = xparam(3);
eta_tax  = xparam(4);
ro_z     = xparam(5);
sig_z    = xparam(6);
sig_cs   = xparam(7);
sig_sb   = xparam(8);
sig_tx   = xparam(9);

thta_wcap = 0.0;
estimated_parameters = [thta_wcap; eta_cs; pphi];
% -------------------------------------------------------------------------




%% save important stuff into temporary .xlsx files
% -------------------------------------------------------------------------
cd(ExcelFolder)
datamoments = data(rownr,6:25)';
xlswrite('data_moments.xlsx',datamoments);
if strcmp(preferences , 'CD') == 1
    xlswrite('preferences.xlsx',0);
elseif strcmp(preferences , 'GHH') == 1
    xlswrite('preferences.xlsx',1);
end
xlswrite('counterfactual.xlsx',counterfactual);
% -------------------------------------------------------------------------


%% calculate steady-state and initial guess
% -------------------------------------------------------------------------
cd(MatlabFolder)
%if counterfactual ~= 0
    if     counterfactual == 1 || ...   % changing size of transfers
            counterfactual == 3 || ...   % changing size and cycle of transfers
            counterfactual == 4 || ...   % changing taxes
            counterfactual == 5 
        xinput = xinput(1:7,1);
     elseif counterfactual == 2
        xinput = xinput(1:2,1);
    end
    
%else
    
%    xinput = xinput(1:2,1);
%end

AMJR_compute_ststate;
calibrated_parameters = [dbar; bgbar; sbbar; gama; ...
    tauk; tauc; taul_rich; taul_poor];




chiR = chi;
chiP = chi;
% -------------------------------------------------------------------------


%% save calibration results to a separate file
% -------------------------------------------------------------------------
cd(ResultsFolder)
savefile = strcat(preferences,'_','counterfactualcalibration_',num2str(counterfactual),'.mat');
save(savefile);
% -------------------------------------------------------------------------


cd(DynareFolder)
%% save steady-state guess
% -------------------------------------------------------------------------
fid = fopen('ststate_guess.txt','wt+');
fprintf(fid,'y         = %8.8f; \n',log(Y));
fprintf(fid,'cagg      = %8.8f; \n',log(C));
fprintf(fid,'ellR      = %8.8f; \n',log(ellR));
fprintf(fid,'ellP      = %8.8f; \n',log(ellP));
fprintf(fid,'cR        = %8.8f; \n',log(cR));
fprintf(fid,'cP        = %8.8f; \n',log(cP));
fprintf(fid,'inv       = %8.8f; \n',log(I));
fprintf(fid,'nxy       = %8.8f; \n',NX/Y);
fprintf(fid,'k         = %8.8f; \n',log(K/NR));
fprintf(fid,'debt      = %8.8f; \n',dbar);
%fprintf(fid,'bgov      = %8.8f; \n',0.00);
%fprintf(fid,'tax_lump  = %8.8f; \n',log(TAX_LUMPSUM));
fprintf(fid,'z         = %8.8f; \n',0.0);
fprintf(fid,'g         = %8.8f; \n',mug);
fprintf(fid,'sb        = %8.8f; \n',log(sbbar));
fprintf(fid,'rmex      = %8.8f; \n',log(Rstar));
fprintf(fid,'r         = %8.8f; \n',log(Rstar));
fprintf(fid,'cs        = %8.8f; \n',0.0);
fprintf(fid,'t_hat     = %8.8f; \n',0.0);
fprintf(fid,'taxes     = %8.8f; \n',log(TAX_LABOR + TAX_CONS + TAX_CAPITAL));
fprintf(fid,'gama      = %8.8f; \n',log(gama));
fprintf(fid,'lshare    = %8.8f; \n',log(LSHARE));
fclose(fid);
% -------------------------------------------------------------------------


%% save deep parameters
% -------------------------------------------------------------------------
fid = fopen('deep_params.txt','wt+');
fprintf(fid,'@#define ghh   = %d  \n',GHH);
fprintf(fid,'@#define cd    = %d  \n',CD);
fprintf(fid,'@#define sep   = %d  \n',SEP);
fprintf(fid,'     \n' );
fprintf(fid,'     \n' );
fprintf(fid,'betta          = %6.6f; \n',betta);
fprintf(fid,'sgma           = %6.6f; \n',sgma);
fprintf(fid,'mug            = %6.6f; \n',mug);
fprintf(fid,'Rstar          = %6.6f; \n',Rstar);
fprintf(fid,'NR             = %6.6f; \n',NR);
fprintf(fid,'NP             = %6.6f; \n',NP);
fprintf(fid,'gamabar        = %6.6f; \n',gama);
fprintf(fid,'nuR            = %6.6f; \n',nuR);
fprintf(fid,'nuP            = %6.6f; \n',nuP);
fprintf(fid,'chi            = %6.6f; \n',chi);
fprintf(fid,'chiR           = %6.6f; \n',chiR);
fprintf(fid,'chiP           = %6.6f; \n',chiP);
fprintf(fid,'dlta           = %6.6f; \n',dlta);
fprintf(fid,'alfa           = %6.6f; \n',alfa);
fprintf(fid,'kapa           = %6.6f; \n',kapa);
fprintf(fid,'kapa_g         = %6.6f; \n',kapa_g);
fprintf(fid,'dbar           = %6.6f; \n',dbar);
fprintf(fid,'sbbar          = %6.6f; \n',sbbar);
fprintf(fid,'thta_wcap      = %6.6f; \n',thta_wcap);
fprintf(fid,'tauc           = %6.6f; \n',tauc);
fprintf(fid,'tauk           = %6.6f; \n',tauk);
fprintf(fid,'taul_poor      = %6.6f; \n',taul_poor);
fprintf(fid,'taul_rich      = %6.6f; \n',taul_rich);
fprintf(fid,'taxlbar        = %6.6f; \n',TAX_LUMPSUM);
fprintf(fid,'eta_cs         = %6.6f; \n',eta_cs);
fprintf(fid,'pphi           = %6.6f; \n',pphi);
fprintf(fid,'eta_sb         = %6.6f; \n',eta_SB);
fprintf(fid,'eta_tax        = %6.6f; \n',eta_tax);
fprintf(fid,'eta_gama       = %6.6f; \n',0.0);
fprintf(fid,'ro_z           = %6.6f; \n',ro_z);
fprintf(fid,'sig_z          = %6.6f; \n',sig_z);
fprintf(fid,'sig_cs         = %6.6f; \n',sig_cs);
fprintf(fid,'sig_s          = %6.6f; \n',sig_sb);
fprintf(fid,'sig_tx         = %6.6f; \n',sig_tx);
fprintf(fid,'ybar           = %6.6f; \n',log(Y));
fclose(fid);
% -------------------------------------------------------------------------




%% RUN DYNARE
% -------------------------------------------------------------------------
dynare RBC_distaxes_onesector
% -------------------------------------------------------------------------


%% SET UP FOR THE COUNTER-FACTUAL SIMULATION

global data_moments moments_targeted cntry prefs
global M_ oo_ options_
cd excel_files
data_moments = xlsread('data_moments.xlsx');
utility_function = xlsread('preferences.xlsx');
scenario = xlsread('counterfactual.xlsx');
if utility_function == 1
    prefs = 'GHH';
elseif utility_function == 0
    prefs = 'CD';
end


%% LOAD ESTIMATION RESULTS
% ----------------------------------------------------------
cd ..
cd results
loadfile = strcat(prefs,'_developed_estimation_v3.mat');
load(loadfile)
MODEL_DATA_DEVELOPED   = MODEL_DATA;
PARAM_ERRORS_DEVELOPED = PARAM_ERRORS;
loadfile = strcat(prefs,'_emerging_estimation_v3.mat');
load(loadfile)
MODEL_DATA_EMERGING   = MODEL_DATA;
PARAM_ERRORS_EMERGING = PARAM_ERRORS;
% ----------------------------------------------------------

if scenario == 10
    MODEL_DATA = MODEL_DATA_DEVELOPED;
end

%% SIMULATE COUNTER-FACTUALS
% ----------------------------------------------------------


%% simulation parameters
global nperiods replications shocks burnin
nperiods = 2000;             
burnin   = 500;              
replications = 2500;         
randn('seed',1);
shocks = randn(nperiods,M_.exo_nbr,replications);


global roR sig_r
%% results from AR(1) regression of r^USA
sdevR = .0229;
varR  = sdevR^2;
roR   = 0.8107;
sig_r = varR*(1-roR^2);
sig_r = sig_r^0.5;

%%
% 1 - benefits: size
% 2 - benefits: cyclicality
% 3 - benefits: size and cyclicality
% 4 - taxes: size and cyclicality
% 5 - benefits and taxes
% 6 - inequality: wealth
% 7 - inequality: income
% 8 - inquality both
% 9 - inequality, benefits, and taxes

%
% xparam = [%   eta_cs           1)
%               inv adj cost     2)
%               eta_sb           3)
%               eta_tx           4)
%               eta_gama         5)
%               rho_z            6)
%               sig_z            7)
%               sig_cs           8)
%               sig_sb           9)
%               sig_tx           10)

xparam_developed = PARAM_ERRORS_DEVELOPED(:,1);
xparam_emerging  = PARAM_ERRORS_EMERGING(:,1);
if scenario ~= 10
    xparam = xparam_emerging;
else
    xparam = xparam_developed;
end


if scenario == 2 || scenario == 3       % cycle or size and cycle of benefits
    indeksy = [3];
elseif scenario == 4                    % taxes
    indeksy = [4];
elseif scenario == 5                    % taxes and benefits combined
    indeksy = [3;4];
elseif scenario == 11  % z = 0
    indeksy = [];
    xparam(6) = 0.0000001;
elseif scenario == 12  % sigr and sigcs = 0
    indeksy = [];
    xparam(7) = 0.0000001;
    xparam(1) = 0.0000000;  
    sig_r = 0.0000001;
else
    indeksy = [];                       % no changes in cyclical/estimated stuff
end
xparam(indeksy,1) = xparam_developed(indeksy,1);

% ----------------------------------------------------------


cd ..
cd matlab_files


global cons_rich cons_poor labor_rich labor_poor
% simulate TxN matrices of consumption and labor supply
% T = number of time periods
% N = number of simulations
disp(' ')
disp(' simulating time series ')


% simulate 
tic
[cons_poor, cons_rich, labor_poor, labor_rich, sbens, taxh, zzz] = AMJR_simulations(xparam);
toc
c_rich0 = cons_rich;
c_poor0 = cons_poor;
l_rich0 = labor_rich;
l_poor0 = labor_poor;


%% compute welfare for poor, rich, and total
% -----------------------------------------------------------------------
disp(' ')
disp(' computing welfare for scenario ')
disp(scenario)
disp(' ------------------------------------------- ')
[vp, vr, v] = AMJR_welfare(cons_poor, cons_rich, labor_poor, labor_rich);
% vp = utility of the poor
% vr = utility of the rich
% v = weighted sum vp and vr
% -----------------------------------------------------------------------


%% save welfare results
% -----------------------------------------------------------------------
cd ..
cd results
savefile = strcat(prefs,'_welfare_',num2str(scenario),'.mat');
save(savefile, 'vp','vr','v','cons_rich','cons_poor','labor_rich','labor_poor');
% -----------------------------------------------------------------------


cequivalence = zeros(3,12);





%% now we can compute allocations for the benchmark economy
if scenario == 0 % 0 = benchmark
    vp0 = vp;
    vr0 = vr;
    v0 = v;
    c_rich0 = cons_rich;
    c_poor0 = cons_poor;
    l_rich0 = labor_rich;
    l_poor0 = labor_poor;
    sbens0  = sbens;
    taxh0   = taxh;
    zzz0    = zzz;
    
    
    
    
    %% loop over scenarios 
    counters = [1,2,3,4,5,11,12];
    for ii = counters % loop over counterfactuals
        
        
        loadfile = strcat(prefs,'_welfare_',num2str(ii),'.mat');
        load(loadfile,'vp','vr','v','cons_rich','cons_poor','labor_rich','labor_poor'); % load only target levels of utility
        cd ..
        cd matlab_files

        disp('scenario = ')
        disp(ii)
        
        % welfare change for the poor
        clow = -0.50;
        chih =  0.50;
        disp('computing poor welfare change')
        while chih - clow > 0.000001    % start bisection
            ceq = (chih + clow)/2;
            c_poor = c_poor0*exp(ceq);
            c_rich = c_rich0;
            l_poor = l_poor0;
            l_rich = l_rich0;
            [vp01, vr01, v01] = AMJR_welfare(c_poor,c_rich,l_poor,l_rich);
            if vp01 == vp
                break;
            elseif vp01 > vp
                chih = ceq;
            elseif vp01 < vp
                clow = ceq;
            end
        end
        cequivalence(1,ii) = 100*(exp(ceq)-1);
        
        % welfare change for the rich
        clow = -0.500;
        chih =  0.500;
        disp('computing rich welfare change')
        while chih - clow > 0.00000001    % start bisection
            ceq = (chih + clow)/2;
            c_poor = c_poor0;
            c_rich = c_rich0*exp(ceq);
            l_poor = l_poor0;
            l_rich = l_rich0;
            [vp01, vr01, v01] = AMJR_welfare(c_poor,c_rich,l_poor,l_rich);
            if vr01 == vr
                break;
            elseif vr01 > vr
                chih = ceq;
            elseif vr01 < vr
                clow = ceq;
            end
        end
        cequivalence(2,ii) = 100*(exp(ceq)-1);
        
        
        % total welfare change
        clow = -0.50;
        chih =  0.50;
        disp('computing total welfare change')
        while chih - clow > 0.000001    % start bisection
            ceq = (chih + clow)/2;
            c_rich = c_rich0*exp(ceq);
            c_poor = c_poor0*exp(ceq);
            l_poor = l_poor0;
            l_rich = l_rich0;
            [vp01, vr01, v01] = AMJR_welfare(c_poor,c_rich,l_poor,l_rich);
            if v01 == v
                break;
            elseif v01 > v
                chih = ceq;
            elseif v01 < v
                clow = ceq;
            end
        end
        cequivalence(3,ii) = 100*(exp(ceq)-1);
        
        
        disp(cequivalence(:,ii)')
        
        
        cd ..
        cd results
    end


WELFARE_TABLE = cequivalence(1:3,counters);
disp(WELFARE_TABLE)


    savefile = strcat(prefs,'_Welfare_Results.mat');
    save(savefile,'WELFARE_TABLE');

end







