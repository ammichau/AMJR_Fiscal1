% -------------------------------------------------------------------------
%   Df.m
%
%   Calculates derivative/gradient/jacobian of a function
%
%   INPUTS:
%   funkcja:    a function f: R^m -> R^n
%   x: a point in R^m at which the Jacobian is evaluated
%
%   OUTPUT:     _                              _
%               |  df_1     df_1          df_1  |
%               | ------,  ------,  ..., ------ |
%               |  dx_1     dx_2          dx_m  |
%               |    .                      .   |
%   ggradient = |    .                      .   |
%               |    .                      .   |
%               |  df_n                   df_n  |
%               | ------,       ...,     ------ |    
%               |  dx_1                   dx_m  |
%               
%   (c) Jacek Rothert, May 2008
%
% Feel free to e-mail me your comments and/or suggestions for improvement.
% -------------------------------------------------------------------------

function ggradient = Df(funkcja,x)
n = length(feval(funkcja,x));
ggradient=zeros(n,length(x));
for kk=1:length(x)
    xhigh = x;
    xlow = x;
    h = 0.000000001*max(1,abs(x(kk)));
    xhigh(kk) = x(kk) + h;
    xlow(kk) = x(kk) - h;
    for jj = 1:n
        fhigh = feval(funkcja,xhigh);
        flow  = feval(funkcja,xlow);
        ggradient(jj,kk) = (fhigh(jj) - flow(jj))/(xhigh(kk)-xlow(kk));
    end
end

