
function [cons_poor, cons_rich, labor_poor, labor_rich, sbenefits, taxhats, zzzs] = AMJR_simulations(xparams)

%% global variables
global M_ oo_ options_ QQ;
global replications shocks burnin 
global roR sig_r

xin = 1;
% -------------------------------------------------------------------------
set_param_value( 'eta_cs',      xparams(xin)  ); xin = xin+1;
set_param_value( 'pphi',        xparams(xin)  ); xin = xin+1;
set_param_value( 'eta_sb',      xparams(xin)  ); xin = xin+1;
set_param_value( 'eta_tax',     xparams(xin)  ); xin = xin+1;
set_param_value( 'ro_z',        xparams(xin)  ); xin = xin+1;
sig_z  = xparams(xin); xin = xin+1;
sig_cs = xparams(xin); xin = xin+1;
sig_s  = xparams(xin); xin = xin+1;
sig_tx = xparams(xin); 
% -------------------------------------------------------------------------
set_param_value( 'ro_g',        0.00);      % we don't do a trend shock
set_param_value( 'ro_r',        roR);
sig_g = 0.000001;                            % we don't do a trend shock


%% DEFINE M_sigma and QQ MATRIX
% ------------------------------------------------------
xin = 1;
M_.Sigma_e(xin, xin) = sig_z^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_g^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_r^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_cs^2;    xin = xin+1;
M_.Sigma_e(xin, xin) = sig_s^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_tx^2;
QQ = chol(M_.Sigma_e);
% ------------------------------------------------------



% solve dynare with these different parameters
% ------------------------------------------------------
cd ..
[oo_.dr,info,M_,options_,oo_] = resol(0,M_,options_,oo_);
cd matlab_files
% ------------------------------------------------------




%% SIMULATE MODEL

cons_poor  = zeros(size(shocks,1)-burnin,replications);
cons_rich  = cons_poor;
labor_poor = cons_poor;
labor_rich = cons_poor;
sbenefits  = cons_poor;
taxhats    = cons_poor;
zzzs       = cons_poor;

for ii = 1:replications
    
    % define shock matrix for ii^th replication
    shock_matrix = QQ*shocks(:,:,ii)';
    
    % simulate series using decision rules obtained from Dynare
    YYY = simulate_dynareseries(oo_,shock_matrix);
    
    % burn the first 1/3 of observations
    YYY(:,1:burnin) = [];
    % ---------------------------------------------------------------------
    
    % extract series we're interested in
    % ---------------------------------------------------------------------    
    cP_timeseries   = YYY(strmatch('cP',    M_.endo_names,'exact'),:);    % cons poor
    cR_timeseries   = YYY(strmatch('cR',    M_.endo_names,'exact'),:);    % cons rich
    ellP_timeseries = YYY(strmatch('ellP',  M_.endo_names,'exact'),:);    % labor poor
    ellR_timeseries = YYY(strmatch('ellR',  M_.endo_names,'exact'),:);    % labor rich
    % ---------------------------------------------------------------------
    
    c_P = exp(cP_timeseries)';
    c_R = exp(cR_timeseries)';
    l_P = exp(ellP_timeseries)';
    l_R = exp(ellR_timeseries)';
    
    cons_poor(:,ii)  = c_P;
    cons_rich(:,ii)  = c_R;
    labor_poor(:,ii) = l_P;
    labor_rich(:,ii) = l_R;
    
end

