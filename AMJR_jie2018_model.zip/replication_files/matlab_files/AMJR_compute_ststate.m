% before running this file make sure
% (1) you defined xinput
% (2) you defined the globals that AMJR_distaxes_ststate.m uses
xin = fsolve('AMJR_distaxes_ststate',xinput);
% -------------------------------------------------------------------------
ellR    = exp(xin(1,1));
ellP    = exp(xin(2,1));
% -------------------------------------------------------------------------




%% SOME AGGREGATE VARIABLES
% -------------------------------------------------------------------------
% labor
L  = (ellR)*NR + gama*(ellP)*NP;
% capital stock
K = exp(mug)*L * ( alfa*exp(-tauk)/(Rstar-1+dlta) )^( 1/(1-alfa) );
% output
Y = K^alfa * (exp(mug)*L)^(1-alfa);
% investment expenditure
I  = (exp(mug) - 1 + dlta)*K;
% -------------------------------------------------------------------------



%% WAGES
% -------------------------------------------------------------------------
% pre-tax wages
w_rich = (1-alfa)*Y/L / ( 1 + thta_wcap*(Rstar-1) );    % benchmark wage, with working capital constraint)
w_poor = w_rich*gama;                                   % adj. for productivity for the rich
% after-tax wages
w_poor_aftertax = w_poor*exp(-taul_poor);
w_rich_aftertax = w_rich*exp(-taul_rich);
% -------------------------------------------------------------------------


%% CAPITAL EARNINGS
r  = alfa*Y/K;
rK = r*K;



%% TRADE BALANCE, NET FACTOR PAYMENTS AND AGGREGATE CONSUMPTION
% -------------------------------------------------------------------------

% current account + (Rstar-exp(mug))*bgbar
NX = NR*(Rstar-exp(mug))*dbar  + thta_wcap*(Rstar-1)*(1-alfa)*Y;
NFP_PRIVATE = - NR*(Rstar-exp(mug))*dbar - thta_wcap*(Rstar-1)*(1-alfa)*Y;

% consumption expenditure
C = Y - I - NX;

% -------------------------------------------------------------------------

if  strcmp(preferences , 'GHH') == 1
    cP = max((w_poor*(ellP) + sbbar/NP),0.00001)  * exp(-tauc);
    cR = max((C - cP*NP)/NR,0.00001);
elseif strcmp(preferences , 'CD') == 1
    cR = w_rich_aftertax * exp(-tauc) * chi/(1-chi) * (1-ellR);
    cP = w_poor_aftertax * exp(-tauc) * chi/(1-chi) * (1-ellP);
elseif strcmp(preferences , 'separable') == 1
    cR = (w_rich_aftertax * exp(-tauc)  / chi / ellR^nuR)^(1/sgma);
    cP = (w_poor_aftertax * exp(-tauc)  / chi / ellP^nuP)^(1/sgma);
end




%% GOVERNMENT INCOME AND EXPENDITURES
% -------------------------------------------------------------------------
TAXES       = sbbar + ( Rstar-exp(mug) )*bgbar;
TAX_LABOR   = taul_rich*w_rich*ellR*NR + taul_poor*w_poor*ellP*NP;
TAX_CONS    = tauc*(cR*NR + cP*NP);
TAX_CAPITAL = tauk*rK;
TAX_LUMPSUM = TAXES - TAX_LABOR - TAX_CONS - TAX_CAPITAL;
% -------------------------------------------------------------------------
if TAX_LUMPSUM < 0
    warning('TAX_LUMPSUM is negative!!!')
end


%% labor share
LINCPOOR = NP*w_poor*ellP;
LINCRICH = NP*w_rich*ellR;

LSHARE = (LINCPOOR + LINCRICH)/Y;

%% STEADY STATE
TAX_RICH = taul_rich*w_rich*ellR*NR + tauc*cR*NR +  tauk*rK + TAX_LUMPSUM;
ststate = [
    (cR);    ...
    (cP);    ...
    (NR*cR/C);    ...
    (NP*cP/C);    ...
    K; ...
    L;       ...
    TAX_RICH/Y;  ...
    LINCRICH / (LINCRICH + rK);  ...    
    ellR; ...
    ellP; ...
    LINCPOOR/Y; ...
    sbbar/LINCPOOR
    ];

% this is the old part - uncomment if you want to go back to what you did
% during estimation and counterfactuals
% ststate = [
%     log(Y);     ...
%     log(C);     ...
%     log(ellR);  ...
%     log(ellP);  ...
%     log(cR);    ...
%     log(cP);    ...
%     log(I);     ...
%     log(K/NR);  ...
%     dbar;       ...
%     0;          ...
%     mug;        ...
%     log(sbbar); ...
%     bgbar;      ...
%     NX/Y;       ...
%     log(TAX_LABOR + TAX_CONS + TAX_CAPITAL)  ...
%     ];
