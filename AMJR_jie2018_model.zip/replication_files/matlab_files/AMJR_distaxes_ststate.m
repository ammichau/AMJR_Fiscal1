function yout = AMJR_distaxes_ststate(xin)

%% description of xin
% xin(1)   = ellR
% xin(2)   = ellP
% xin(3)   = sbbar    (optional)
% xin(4)   = tauk     (optional)
% xin(5)   = tauc     (optional)
% xin(6)   = taulrich (optional)
% xin(7)   = taulpoor (optional)
% xin(8)   = gama     (optional)
% xin(9)   = dbar     (optional)
% xin(10)  = bgbar    (optional)

global deep_parameters
global COUNTRY_MOMENTS
global estimated_parameters
global bgbar sbbar dbar gama
global tauk tauc taul_rich taul_poor
global counterfactual
global calibrated_parameters_developed
global calibrated_parameters

thta_wcap = estimated_parameters(1,1);

% --------------------------------------------
sgma    = deep_parameters(2,1);
mug     = deep_parameters(3,1);
dlta    = deep_parameters(4,1);
alfa    = deep_parameters(5,1);
Rstar   = deep_parameters(6,1);

GHH     = deep_parameters(9,1);
CD      = deep_parameters(10,1);
SEP     = deep_parameters(11,1);
nuR     = deep_parameters(12,1);
nuP     = deep_parameters(13,1);
chi     = deep_parameters(14,1);
chiR = chi;
chiP = chi;
% --------------------------------------------


% --------------------------------------------
ncm = 1;
NR          = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
INCSHARE    = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
INT_GDP     = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
SBEN_GDP    = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
DEBT_GDP    = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
NP          = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
VATperc     = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
PITperc     = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
CITperc     = COUNTRY_MOMENTS(ncm,1); ncm = ncm+1;
PITE        = COUNTRY_MOMENTS(ncm,1);
% --------------------------------------------



yout = ones(length(xin),1);

ellR    = exp(xin(1,1));
ellP    = exp(xin(2,1));


if exist('counterfactual') == 0 
    
    if length(xin) ~= 10
        error('vector guess for steady-state must have 10 elements')
    end

    sbbar       = xin(3,1);
    xin(4:7,1)  = xin(4:7,1) ./ ( 1 + abs(xin(4:7,1)) );
    tauk        = xin(4,1);
    tauc        = xin(5,1);
    taul_rich   = xin(6,1);
    taul_poor   = xin(7,1);
    gama        = exp( xin(8,1) );    
    dbar        = xin(9,1);
    bgbar       = xin(10,1);
    
elseif counterfactual == 0 || counterfactual == 10  || counterfactual == 11  || counterfactual == 12
     
    if length(xin) ~= 10
        error('vector guess for steady-state must have 10 elements')
    end

    sbbar       = xin(3,1);
    xin(4:7,1)  = xin(4:7,1) ./ ( 1 + abs(xin(4:7,1)) );
    tauk        = xin(4,1);
    tauc        = xin(5,1);
    taul_rich   = xin(6,1);
    taul_poor   = xin(7,1);
    gama        = exp( xin(8,1) );    
    dbar        = xin(9,1);
    bgbar       = xin(10,1);
    
elseif counterfactual == 1 || ...   % changing size of transfers
       counterfactual == 3 || ...   % changing size and cycle of transfers
       counterfactual == 4 || ...   % changing taxes
       counterfactual == 5          % changing transfers and taxes

    if length(xin) ~= 7
        error('for this counterfactual vector guess for steady-state must have 7 elements')
    end    
    
    sbbar       = xin(3,1);
    xin(4:7,1) = xin(4:7,1) ./ ( 1 + abs(xin(4:7,1)) );
    tauk        = xin(4,1);
    tauc        = xin(5,1);
    taul_rich   = xin(6,1);
    taul_poor   = xin(7,1);
    gama        = calibrated_parameters(4,1);
    dbar        = calibrated_parameters(1,1);
    bgbar       = calibrated_parameters(2,1);
  
elseif counterfactual == 6   || ...
        counterfactual == 2  
    
    if length(xin) ~= 2
        error('for this counterfactual vector guess for steady-state must have 2 elements')
    end   
    sbbar       = calibrated_parameters(3,1);    
    tauk        = calibrated_parameters(5,1);    
    tauc        = calibrated_parameters(6,1);    
    taul_rich   = calibrated_parameters(7,1);    
    taul_poor   = calibrated_parameters(8,1);    
    gama        = calibrated_parameters(4,1);
    dbar        = calibrated_parameters(1,1);
    bgbar       = calibrated_parameters(2,1);    
    
elseif counterfactual == 7    
    if length(xin) ~= 2
        error('for this counterfactual vector guess for steady-state must have 3 elements')
    end
    sbbar       = calibrated_parameters(3,1);    
    tauk        = calibrated_parameters(5,1);    
    tauc        = calibrated_parameters(6,1);    
    taul_rich   = calibrated_parameters(7,1);    
    taul_poor   = calibrated_parameters(8,1);
    gama        = calibrated_parameters_developed(4,1);
    dbar        = calibrated_parameters(1,1);
    bgbar       = calibrated_parameters(2,1);
    
elseif counterfactual == 8        
    if length(xin) ~= 2
        error('for this counterfactual vector guess for steady-state must have 3 elements')
    end 
    sbbar       = calibrated_parameters(3,1);    
    tauk        = calibrated_parameters(5,1);    
    tauc        = calibrated_parameters(6,1);    
    taul_rich   = calibrated_parameters(7,1);    
    taul_poor   = calibrated_parameters(8,1);  
    gama        = calibrated_parameters_developed(4,1);
    dbar        = calibrated_parameters(1,1);
    bgbar       = calibrated_parameters(2,1);    
    
elseif counterfactual == 9      
    
     if length(xin) ~= 7
         error('for this counterfactual vector guess for steady-state must have 8 elements')
     end    
        
     sbbar       = xin(3,1);
     xin(4:7,1) = xin(4:7,1) ./ ( 1 + abs(xin(4:7,1)) );
     tauk        = xin(4,1);
     tauc        = xin(5,1);
     taul_rich   = xin(6,1);
     taul_poor   = xin(7,1);
    gama        = calibrated_parameters_developed(4,1); 
    dbar        = calibrated_parameters(1,1);
    bgbar       = calibrated_parameters(2,1);    
    
end







if abs(CD - 1) < 0.001
    ellR = min(ellR,0.999);
    ellP = min(ellP,0.999);
end




%% SOME AGGREGATE VARIABLES
% -------------------------------------------------------------------------
% labor
L  = (ellR)*NR + gama*(ellP)*NP;
% capital stock
K = exp(mug)*L * ( alfa*exp(-tauk)/(Rstar-1+dlta) )^( 1/(1-alfa) );
% output
Y = K^alfa * (exp(mug)*L)^(1-alfa);
% investment expenditure
I  = (exp(mug) - 1 + dlta)*K;
% -------------------------------------------------------------------------



%% WAGES
% -------------------------------------------------------------------------
% pre-tax wages
w_rich = (1-alfa)*Y/L / ( 1 + thta_wcap*(Rstar-1) );    % benchmark wage, with working capital constraint)
w_poor = w_rich*gama;                                   % adj. for productivity for the rich

% after-tax wages
w_poor_aftertax = w_poor*exp(-taul_poor);
w_rich_aftertax = w_rich*exp(-taul_rich);
% -------------------------------------------------------------------------


%% TRADE BALANCE, NET FACTOR PAYMENTS AND AGGREGATE CONSUMPTION
% -------------------------------------------------------------------------
%+ (Rstar-exp(mug))*bgbar
% current account
NX = NR*(Rstar-exp(mug))*dbar + thta_wcap*(Rstar-1)*(1-alfa)*Y;
NFP_PRIVATE = - NR*(Rstar-exp(mug))*dbar - thta_wcap*(Rstar-1)*(1-alfa)*Y;

% consumption expenditure
C = Y - I - NX;

% -------------------------------------------------------------------------


if  abs(GHH - 1) < 0.001
    cP = max((w_poor_aftertax*(ellP) + sbbar/NP),0.00001) * exp(-tauc);
    cR = max((C - cP*NP)/NR,0.00001);
elseif abs(CD - 1) < 0.001
    cR = w_rich_aftertax * exp(-tauc) * chi/(1-chi) * (1-ellR);
    cP = w_poor_aftertax * exp(-tauc) * chi/(1-chi) * (1-ellP);
elseif abs(SEP - 1) < 0.001
    cR = (w_rich_aftertax * exp(-tauc) / chi / ellR^nuR)^(1/sgma);
    cP = (w_poor_aftertax * exp(-tauc) / chi / ellP^nuP)^(1/sgma);
end



%% CAPITAL EARNINGS
r = alfa*Y/K;
rK = r*K;


%% GOVERNMENT INCOME AND EXPENDITURES
% -------------------------------------------------------------------------
TAXES       = sbbar + ( Rstar-exp(mug) )*bgbar;
TAX_LABOR   = taul_rich*w_rich*ellR*NR + taul_poor*w_poor*ellP*NP;
TAX_CONS    = tauc*(cR*NR + cP*NP);
TAX_CAPITAL = tauk*rK;
TAX_LUMPSUM = TAXES - TAX_LABOR - TAX_CONS - TAX_CAPITAL;

% -------------------------------------------------------------------------


% income share of the rich
inc_rich = rK + NR*w_rich*ellR + NFP_PRIVATE - taul_rich*w_rich*ellR*NR - tauk*rK;
inc_poor = NP*w_poor*ellP - taul_poor*w_poor*ellP*NP;
incshare_rich = inc_rich / (inc_rich + inc_poor);


taul_avg = TAX_LABOR / (NR*w_rich*ellR + NP*w_poor*ellP);
PITE_MODEL = taul_rich/taul_avg;


if  abs(GHH - 1) < 0.001
    yout(1,1) = chiR * ellR^nuR - w_rich_aftertax;
    yout(2,1) = chiP * ellP^nuP - w_poor_aftertax;
else
    yout(1,1) = C - (NP*(cP) + NR*(cR));
    yout(2,1) = w_poor_aftertax*(ellP) + sbbar/NP - (cP*exp(tauc));
end

match_sbar          = sbbar/Y       - SBEN_GDP;
match_VAT           = TAX_CONS      - VATperc*TAXES;
match_CIT           = TAX_CAPITAL   - CITperc*TAXES;
match_PIT           = TAX_LABOR     - PITperc*TAXES;
match_MargAvg       = PITE          - PITE_MODEL;
match_incomeshare   = incshare_rich - INCSHARE;
match_dbar          = dbar/Y        - DEBT_GDP;
match_bgbar         = ( Rstar-exp(mug) )*bgbar / Y - INT_GDP;


if length(xin) > 2 
    yout(3:7,1) = [match_sbar;match_VAT;match_CIT;match_PIT;match_MargAvg];
end

if length(xin) == 10
    yout(8:10,1) = [match_incomeshare;match_dbar;match_bgbar];
end


