%% basic description
% -------------------------------------------------------------------------
% xinput = vector of parameters to be estimated
% youtput = sum_i (model_moment_i - data_moment_i)^2; OR
% youtput = model_moments - data_moments
% (if using fsolve to match them all exactly)
% -------------------------------------------------------------------------
%
% calls:
% 1) resol (resolves the model in Dynare)
% 2) smm_calculate_moments (uses Dynare's decision rules to compute
% model simulated moments)
%
%
% NOTE: if xinput has a BIG impact on steady-state, you may want to set
% redo_stst = 1
% -------------------------------------------------------------------------

function [youtput, WW] = AMJR_smm_objective_annual(xparams)

%% global variables
global M_ oo_ options_ QQ;
global data_moments moments_targeted
global replications shocks burnin estimation
global roR sig_r
global XX1
global compute_stst
global stst_guess

xin = 1;
% -------------------------------------------------------------------------
set_param_value( 'eta_cs',      xparams(xin)  );xin = xin+1;
set_param_value( 'pphi',        xparams(xin)  );xin = xin+1;
set_param_value( 'eta_sb',      xparams(xin)  );xin = xin+1;
set_param_value( 'eta_tax',     xparams(xin)  );xin = xin+1;
set_param_value( 'ro_z',        xparams(xin)  );xin = xin+1;
sig_z  = xparams(xin); xin = xin+1;
sig_cs = xparams(xin); xin = xin+1;
sig_s  = xparams(xin); xin = xin+1;
sig_tx = xparams(xin); 
% -------------------------------------------------------------------------

set_param_value( 'ro_g',        0.00);
set_param_value( 'ro_r',        roR);
sig_g = 0.00001;


%% DEFINE M MATRIX
% ------------------------------------------------------
xin = 1;
M_.Sigma_e(xin, xin) = sig_z^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_g^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_r^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_cs^2;    xin = xin+1;
M_.Sigma_e(xin, xin) = sig_s^2;     xin = xin+1;
M_.Sigma_e(xin, xin) = sig_tx^2;
QQ = chol(M_.Sigma_e);
% ------------------------------------------------------

cd ..

[oo_.dr,info,M_,options_,oo_] = resol(0,M_,options_,oo_);
cd matlab_files


npts  = size(shocks,1);
SDEVS = zeros(10,replications);
CORRS = zeros(7,replications);


%% SIMULATE MODEL MOMENTS AND THEIR STANDARD ERRORS

parfor ii = 1:replications
    
    %% THIS PART IS GENERAL
    % ---------------------------------------------------------------------
    
    % define shock matrix for ii^th replication
    shock_matrix = QQ*shocks(:,:,ii)';
    
    % simulate series using decision rules obtained from Dynare
    YYY = simulate_dynareseries(oo_,shock_matrix);
    
    % burn the first 1/3 of observations
    YYY(:,1:burnin) = [];
    % ---------------------------------------------------------------------
    
    
    
    %% THIS PART IS MODEL-SPECIFIC
    % ---------------------------------------------------------------------
    % extract series we're interested in
    g_timeseries    = YYY(strmatch('g',M_.endo_names,'exact'),:);     % TREND GROWTH
    Gama = zeros(1,length(g_timeseries));                             % TREND
    for t = 2:length(Gama)
        Gama(1,t) = Gama(1,t-1) + g_timeseries(t);
    end
    
    y_timeseries    = YYY(strmatch('y',M_.endo_names,'exact'),:) + Gama;     % GDP
    c_timeseries    = YYY(strmatch('cagg',M_.endo_names,'exact'),:) + Gama;  % C
    cP_timeseries   = YYY(strmatch('cP',M_.endo_names,'exact'),:) + Gama;  % C
    nx_timeseries   = YYY(strmatch('nxy',M_.endo_names,'exact'),:);   % TRADE BALANCE
    i_timeseries    = YYY(strmatch('inv',M_.endo_names,'exact'),:) + Gama;   % I
    sb_timeseries   = YYY(strmatch('sb',M_.endo_names,'exact'),:) + Gama;    % BENEFITS
    tax_timeseries  = YYY(strmatch('taxes',M_.endo_names,'exact'),:) + Gama; % TAX REVENUES
    rmex_timeseries = YYY(strmatch('rmex',M_.endo_names,'exact'),:);  % interest rate
    lshare_timeseries = YYY(strmatch('lshare',M_.endo_names,'exact'),:);  % labor share
    % ---------------------------------------------------------------------
    
    
    % ---------- QUADRATIC TRENDS ----------
    XX = XX1(1:length(y_timeseries),:);
    XXX = (XX'*XX)^(-1)*XX';
    
    % GDP
    bhat = XXX*y_timeseries';
    y = y_timeseries' - XX*bhat;
    
    % CONSUMPTION
    bhat = XXX*c_timeseries';
    c = c_timeseries' - XX*bhat;
    
    % CONSUMPTION POOR
    bhat = XXX*cP_timeseries';
    cP = cP_timeseries' - XX*bhat;
    
    % BENEFITS
    bhat = XXX*sb_timeseries';
    sb = sb_timeseries' - XX*bhat;
    
    % TAXES
    bhat = XXX*tax_timeseries';
    tx = tax_timeseries' - XX*bhat;
    
    % INVESTMENT
    bhat = XXX*i_timeseries';
    in = i_timeseries' - XX*bhat;
    
    % TRADE BALANCE
    bhat = XXX*nx_timeseries';
    nx = nx_timeseries' - XX*bhat;
    
    % LABOR SHARE
    bhat = XXX*lshare_timeseries';
    lshare = lshare_timeseries' - XX*bhat;
    
    
    % LABOR SHARE
    bhat = XXX*rmex_timeseries';
    rmex = rmex_timeseries' - XX*bhat;    
    % ---------------------------------------
    
    
    % ---------- FIRST DIFFERENCES ----------
    dy   = diff(y_timeseries');
    dc   = diff(c_timeseries');
    dcp  = diff(cP_timeseries');
    di   = diff(i_timeseries');
    ds   = diff(sb_timeseries');
    dt   = diff(tax_timeseries');
    dnx  = diff(nx_timeseries');
    dr   = diff(rmex_timeseries');
    % ---------------------------------------
    y(1,:)  = [];
    c(1,:)  = [];
    cP(1,:) = [];
    in(1,:) = [];
    sb(1,:) = [];
    tx(1,:) = [];
    nx(1,:) = [];
    lshare(1,:) = [];
    rmex(1,:) = [];
    
    
    %% define matrices of endogenous variables in the model
    % ---------------------------------------------------------------------
    % var nr:     1 2 3  4  5   6  7    8  9   10
    endvars    = [y c in sb tx dnx dy rmex cP lshare];
    % ---------------------------------------------------------------------
    
    
    %% model moments - annual
    % ---------------------------------------------------------------------
    % compute and record standard deviations - annual
    sdeviations = std(endvars)';
    SDEVS(:,ii) = sdeviations*100;
    % sdeviations
    % 1) gdp
    % 2) cons           ( will be relative to sd(GDP) )
    % 3) invest         ( will be relative to sd(GDP) )
    % 4) benefits       ( will be relative to sd(GDP) )
    % 5) taxes          ( will be relative to sd(GDP) )
    % 6) interest rate
    
    
    % compute and record correlations - annual
    corelations = corr(endvars);
    corels = [  corelations(1,4);                  % corr(GDP, BENEFITS     )
                corelations(1,5);                  % corr(GDP, TAXES     )
                corelations(7,6);                  % corr(\Delta GDP, \Delta TRADE BALANCE/GDP)
                corelations(1,8);                  % corr(GDP, INT. RATE)
                corr(y(1:length(y)-1,1),...   % corr(GDP(t),GDP(t-1))
        y(2:length(y)  ,1));
                corelations(1,2);                   % corr(GDP, CONSUMPTION)
                corelations(1,3)];                  % corr(GDP, INVESTMENT)
    
    CORRS(:,ii) = corels;

    % ---------------------------------------------------------------------
    
    
end

% sd relative to sd(GDP) for C, I, TRANSFERS, TAXES
for nnn = 2:5
SDEVS(nnn,:) = SDEVS(nnn,:)./SDEVS(1,:);    
end

% PICK THE SD THAT WE WANT
SDEVS = SDEVS([1 2 3 4 5 8],:);

% VCOV MATRIX OF MODEL MOMENTS
MMNTS_MODEL_MTRIX = [SDEVS; CORRS];
%MMNTS_MODEL_MTRIX_full = [SDEVS; CORRS];
%MMNTS_MODEL_MTRIX_full; 
%WW = cov(MMNTS_MODEL_MTRIX_full');

% AVERAGES OF SIMULATED MOMENTS OVER ALL REPLICATIONS
SDEVS_MEANS = mean(SDEVS,2);
CORRS_MEANS = mean(CORRS,2);

% VECTOR OF ALL MOMENTS
model_moments_full = [SDEVS_MEANS; CORRS_MEANS];
model_moments = model_moments_full; %(moments_targeted,1);
weighing_matrix = eye(size(model_moments,1));
weighing_matrix(12,12) = 0.000000001;    % CORR(c,y) NOT INCLUDED
weighing_matrix(13,13) = 0.000000001;    % CORR(INV,Y) NOT INCLUDED
weighing_matrix(2,2) = 10; 

youtput = model_moments_full;

if estimation == 2
    youtput = (youtput-data_moments(moments_targeted))'*weighing_matrix*(youtput-data_moments(moments_targeted));
end

if nargout == 2
    WW = cov(MMNTS_MODEL_MTRIX');
end


