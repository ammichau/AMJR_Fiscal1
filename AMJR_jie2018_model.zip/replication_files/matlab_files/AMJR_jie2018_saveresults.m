%% Michaud and Rothert (2018), "Redistributive Policies and Business Cycles 
% in Emerging Economies", Journal of International Economics
% --------------------------------------------------------------------------------
%% _____ REPLICATION FILE FOR: saving all results and replicatin tables __________
%
%   - calls: 
%       a) Inequality_Targets.xlsx (excel file with data stats 
%                                   for calibration and estimation targets)
%       b) GHH_counterfactual_0,1,...,10.mat - 11 different .mat-files with
%       model moments from benchmark simulations, and from counter-factuals
%
%   - output is saved in: Results_GHH_Tables.xlsx
% --------------------------------------------------------------------------------

clear all
clc

% ADD DYNARE PATH
addpath C:\dynare\4.4.3\matlab

% SPECIFY THE MAIN PATH TO THE PROJECT'S PARENT DIRECTORY
mainpath = 'C:\Users\rothert\Dropbox\work\research\ZZZ_PUBLISHED\05_JIE2018_RedistributivePolicies\replication_files\';

ExcelFolder   =  strcat(mainpath,'excel_files');
MatlabFolder  =  strcat(mainpath,'matlab_files');
ResultsFolder =  strcat(mainpath,'results');
DynareFolder  =  mainpath;


cd(ExcelFolder)
data  = xlsread('InequalityTargets.xlsx','data_inputs');

NR          = data(1,1);
INCSHARE    = data(1,2);
INT_GDP     = data(1,3);
SBEN_GDP    = data(1,4);
DEBT_GDP    = data(1,5);
VATperc     = data(1,size(data,2)-3);
PITperc     = data(1,size(data,2)-2);
CITperc     = data(1,size(data,2)-1);
PITE        = data(1,size(data,2));

cd(ResultsFolder)

prefs = 'GHH';
outputfile = strcat('Results_',prefs,'_tables.xlsx');



sheetname = strcat('FullResult_3','.xlsx');

for i = 0:10
    
    loadfile = strcat(prefs,'_counterfactual_',num2str(i),'.mat');
    load(loadfile)
        
    disp([i])
    
    NR          = data(2,1);
    INCSHARE    = data(2,2);
    SBEN_GDP    = data(2,4);
    VATperc     = data(2,size(data,2)-3);
    PITperc     = data(2,size(data,2)-2);
    CITperc     = data(2,size(data,2)-1);
    PITE        = data(2,size(data,2));
    
    TARGETS_DEVELOPED = [SBEN_GDP; VATperc; PITperc; CITperc; PITE; NR; INCSHARE];
    
    NR          = data(1,1);
    INCSHARE    = data(1,2);
    INT_GDP     = data(1,3);
    SBEN_GDP    = data(1,4);
    DEBT_GDP    = data(1,5);
    VATperc     = data(1,size(data,2)-3);
    PITperc     = data(1,size(data,2)-2);
    CITperc     = data(1,size(data,2)-1);
    PITE        = data(1,size(data,2));
    
    if i == 1 || i == 3
        SBEN_GDP    = data(2,4);
    elseif i == 4
        VATperc     = data(2,size(data,2)-3);
        PITperc     = data(2,size(data,2)-2);
        CITperc     = data(2,size(data,2)-1);
        PITE        = data(2,size(data,2));
    elseif i == 5
        SBEN_GDP    = data(2,4);
        VATperc     = data(2,size(data,2)-3);
        PITperc     = data(2,size(data,2)-2);
        CITperc     = data(2,size(data,2)-1);
        PITE        = data(2,size(data,2));
    elseif i == 6
        NR          = data(2,1);
    elseif i == 7
        INCSHARE    = data(2,2);
    elseif i == 8
        NR          = data(2,1);
        INCSHARE    = data(2,2);
    elseif i == 9
        NR          = data(2,1);
        INCSHARE    = data(2,2);
        SBEN_GDP    = data(2,4);
        VATperc     = data(2,size(data,2)-3);
        PITperc     = data(2,size(data,2)-2);
        CITperc     = data(2,size(data,2)-1);
        PITE        = data(2,size(data,2));
    end
    
    
    
    COUNTRY_MOMENTS = [NR; INCSHARE; INT_GDP; SBEN_GDP; DEBT_GDP; ...
        VATperc; PITperc; CITperc; PITE];
    
    if i == 0
        OUTPUT_DATA = [MODEL_DATA_EMERGING(:,3) zeros(size(MODEL_DATA_EMERGING,1),1)];
        OUTPUT_DATA = reshape(OUTPUT_DATA',[size(OUTPUT_DATA,1)*size(OUTPUT_DATA,2),1]);
        D = length(OUTPUT_DATA);
        indices = [2:2:D]';
        OUTPUT_DATA(indices) = NaN;
    elseif i == 10
        OUTPUT_DATA = [MODEL_DATA_DEVELOPED(:,3) zeros(size(MODEL_DATA_DEVELOPED,1),1)];
        OUTPUT_DATA = reshape(OUTPUT_DATA',[size(OUTPUT_DATA,1)*size(OUTPUT_DATA,2),1]);
        D = length(OUTPUT_DATA);
        OUTPUT_DATA(indices) = NaN;
    end
    
    OUTPUT_MODEL = reshape(MODEL_COUNTER',[size(MODEL_COUNTER,1)*size(MODEL_COUNTER,2),1]);
    D = length(OUTPUT_MODEL);
    indices = [2:2:D]';
    OUTPUT_MODEL(indices) = -OUTPUT_MODEL(indices);
    
    
    TARGETS = [SBEN_GDP; VATperc; PITperc; CITperc; PITE; NR; INCSHARE];
    
    if i ~= 0
        for jj = 1:length(TARGETS)
            if abs(TARGETS(jj,1) - TARGETS_DEVELOPED(jj,1)) > 0.001
                TARGETS(jj,1) = NaN;
            end
        end
        for jj = 1:length(xparam)
            if abs(xparam(jj,1) - xparam_developed(jj,1)) > 0.001
                xparam(jj,1) = NaN;
            end
        end
    end
    
    
    if i == 0
        colmn = 'C';
    elseif i == 1
        colmn = 'D';
    elseif i == 2
        colmn = 'E';
    elseif i == 3
        colmn = 'F';
    elseif i == 4
        colmn = 'G';
    elseif i == 5
        colmn = 'H';
    elseif i == 6
        colmn = 'I';
    elseif i == 7
        colmn = 'J';
    elseif i == 8
        colmn = 'K';
    elseif i == 9
        colmn = 'L';
    elseif i == 10
        colmn = 'M';
    end
    
    row_mmts   = '7';
    row_params = '35';
    row_trgets = '47';
    row_calibr = '56';
    
    range_moments = strcat(colmn,row_mmts);
    range_params  = strcat(colmn,row_params);
    range_targets = strcat(colmn,row_trgets);
    range_calibr = strcat(colmn,row_calibr);
    
    
    xlswrite(outputfile,OUTPUT_MODEL,sheetname,range_moments)
    xlswrite(outputfile,xparam,sheetname,range_params)
    xlswrite(outputfile,TARGETS,sheetname,range_targets)
    
    
    if i == 0
        save_calibration = [calibrated_parameters([3 6 8 7 5],1);NR;calibrated_parameters(4,1)];
        xlswrite(outputfile,save_calibration,sheetname,range_calibr)
        xlswrite(outputfile,OUTPUT_DATA,sheetname,'B7')
        xlswrite(outputfile,-PARAM_ERRORS_EMERGING(:,2),sheetname,'B35')
    end
    
    if i == 10
        save_calibration = [calibrated_parameters([3 6 8 7 5],1);TARGETS_DEVELOPED(6,1);calibrated_parameters(4,1)];
        xlswrite(outputfile,save_calibration,sheetname,range_calibr)
        xlswrite(outputfile,OUTPUT_DATA,sheetname,'N7')
        xlswrite(outputfile,TARGETS_DEVELOPED,sheetname,range_targets)
        xlswrite(outputfile,-PARAM_ERRORS_DEVELOPED(:,2),sheetname,'N35')
    end
    
end


    
    loadfile = strcat(prefs,'_Welfare_Results.mat');
    load(loadfile)
    
    xlswrite(outputfile,WELFARE_TABLE,sheetname,'B67')
    


