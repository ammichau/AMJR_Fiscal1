%% Michaud and Rothert (2018), "Redistributive Policies and Business Cycles 
% in Emerging Economies", Journal of International Economics
% --------------------------------------------------------------------------------
%% ______________ REPLICATION FILE FOR: counter-factual experiments ______________ 
%
%   - calls: 
%       a) Inequality_Targets.xlsx (excel file with data stats 
%                                   for calibration and estimation targets)
%       b) AMJR_compute_ststate.m, 
%                       which in turn calls AMJR_distaxes_ststate.m
%       c) RBC_distaxes_onesector.mod (Dynare file for solving the model 
%                                       and computing model decision rules) 
%       d) GHH_developed_estimation_v3.mat and GHH_emerging_estimation_v3.mat
%           to load the results of SMM estimation from earlier
%       e) AMJR_smm_objective_annual.m to compute model moments and
%       standard errors
%
%   - to compute all counter-factuals run the file 11 times, 
%      each time changing line 66 by setting countefactual = 0, 1, 2, ..., 10
% -------------------------------------------------------------------------------


clear all
clc

% ADD DYNARE PATH
addpath C:\dynare\4.4.3\matlab

% SPECIFY THE MAIN PATH TO THE PROJECT'S PARENT DIRECTORY
mainpath = 'C:\Users\rothert\Dropbox\work\research\ZZZ_PUBLISHED\05_JIE2018_RedistributivePolicies\replication_files\';

% DEFINE SUBFOLDERS
ExcelFolder   =  strcat(mainpath,'excel_files');
MatlabFolder  =  strcat(mainpath,'matlab_files');
ResultsFolder =  strcat(mainpath,'results');
DynareFolder  =  mainpath;

ExcelFolder   =  strcat(mainpath,'excel_files');
MatlabFolder  =  strcat(mainpath,'matlab_files');
ResultsFolder =  strcat(mainpath,'results');
DynareFolder  =  mainpath;

%% global variables
global preferences
global country rownr
global deep_parameters
global COUNTRY_MOMENTS
global estimated_parameters
global tauk tauc taul_rich taul_poor
global bgbar sbbar dbar gama
global calibrated_parameters_developed
global calibrated_parameters

global counterfactual
% 0  - emerging benchmark
% 1  - benefits: size
% 2  - benefits: cyclicality
% 3  - benefits: size and cyclicality
% 4  - taxes: size and cyclicality
% 5  - benefits and taxes
% 6  - inequality: wealth
% 7  - inequality: income
% 8  - inquality both
% 9  - inequality, benefits, and taxes
% 10 - developed benchmark
counterfactual = 1;
%% preferences
% ------------------------------------------------------------------------

preferences = 'GHH';
GHH = 0;
CD  = 0;
SEP = 0;
nuR = 0.60;
nuP = nuR;
% 'GHH' or 'CD' or 'separable'
if  strcmp(preferences , 'GHH') == 1
    GHH = 1;
    chi = 1.45;
elseif strcmp(preferences , 'CD') == 1
    CD  = 1;
    chi = 0.60;
elseif strcmp(preferences , 'separable') == 1
    SEP = 1;
    chi = 1.00;
end
% ------------------------------------------------------------------------


%% country and rownr
% ------------------------------------------------------------------------

if counterfactual == 10
    country = 'developed';
else
    country = 'emerging';
end
rownr = 1*strcmp(country,'emerging') + 2*strcmp(country,'developed');
% ------------------------------------------------------------------------


%% deep parameters
% ------------------------------------------------------------------------
betta  = 0.96;      % discount (annual)
sgma   = 2.0000;    % IES
mug    = 0.00;      % balanced growth rate (annual)
dlta   = 0.04;      % depreciation
alfa   = 0.33;      % capital share
kapa   = 0.0001;     % portfolio adj cost private
kapa_g = 0.0001;     % portfolio adj cost govt

% world interest rate
if strcmp(preferences , 'CD') == 1
    Rstar = 1.0/betta * exp(mug)^(1-chi*(1-sgma));
else
    Rstar = 1.0/betta * exp(mug)^sgma;
end
deep_parameters = [betta; sgma; mug; dlta; alfa; Rstar; kapa; kapa_g; ...
    GHH; CD; SEP; ...
    nuR; nuP; chi];
% ------------------------------------------------------------------------


%% COUNTRY MOMENTS
% -------------------------------------------------------------------------
cd(ExcelFolder)
data  = xlsread('InequalityTargets.xlsx','data_inputs');

NR          = data(rownr,1);
INCSHARE    = data(rownr,2);
INT_GDP     = data(rownr,3);
SBEN_GDP    = data(rownr,4);
DEBT_GDP    = data(rownr,5);
VATperc     = data(rownr,size(data,2)-3);
PITperc     = data(rownr,size(data,2)-2);
CITperc     = data(rownr,size(data,2)-1);
PITE        = data(rownr,size(data,2));


if counterfactual == 1 || counterfactual == 3
    SBEN_GDP    = data(rownr+1,4);
elseif counterfactual == 4
    VATperc     = data(rownr+1,size(data,2)-3);
    PITperc     = data(rownr+1,size(data,2)-2);
    CITperc     = data(rownr+1,size(data,2)-1);
    PITE        = data(rownr+1,size(data,2));
elseif counterfactual == 5
    SBEN_GDP    = data(rownr+1,4);
    VATperc     = data(rownr+1,size(data,2)-3);
    PITperc     = data(rownr+1,size(data,2)-2);
    CITperc     = data(rownr+1,size(data,2)-1);
    PITE        = data(rownr+1,size(data,2));
elseif counterfactual == 6 || counterfactual == 8
    NR          = data(rownr+1,1);    
elseif counterfactual == 9
    NR          = data(2,1);
    SBEN_GDP    = data(rownr+1,4);
    VATperc     = data(rownr+1,size(data,2)-3);
    PITperc     = data(rownr+1,size(data,2)-2);
    CITperc     = data(rownr+1,size(data,2)-1);
    PITE        = data(rownr+1,size(data,2));
end
NP = 1 - NR;

COUNTRY_MOMENTS = [NR; INCSHARE; INT_GDP; SBEN_GDP; DEBT_GDP; NP;...
    VATperc; PITperc; CITperc; PITE];
% -------------------------------------------------------------------------


%% LOAD ESTIMATION RESULTS
% ----------------------------------------------------------
cd(ResultsFolder)
loadfile = strcat(preferences,'_',country,'_estimation_v3.mat');
load(loadfile)
xparam = PARAM_ERRORS(:,1);
loadfile = strcat(preferences,'_',country,'_calibration.mat');
load(loadfile)
calibrated_parameters_emerging = calibrated_parameters;

if strcmp(country , 'emerging') == 1
    loadfile = strcat(preferences,'_developed_estimation_v3.mat');
    load(loadfile)
    PARAM_ERRORS_DEVELOPED = PARAM_ERRORS;
    loadfile = strcat(preferences,'_developed_calibration.mat');
    load(loadfile)
    calibrated_parameters_developed = calibrated_parameters;
    
    if counterfactual == 2 || counterfactual == 3
        indeksy = [3];
    elseif counterfactual == 4
        indeksy = [4];        
    elseif counterfactual == 5 
        indeksy = [3;4];
    elseif counterfactual == 7 || counterfactual == 8
        indeksy = [];
    elseif counterfactual == 5 || counterfactual == 9
        indeksy = [3;4];
    else
        indeksy = [];
    end
    xparam(indeksy,1) = PARAM_ERRORS_DEVELOPED(indeksy,1);
    
end
calibrated_parameters = calibrated_parameters_emerging;
% ----------------------------------------------------------
% xparam = [%  \eta_cs          1)
            %  inv adj cost     2)
            %  eta_sb           3)
            %  eta_tx           4)
            %  rho_z            5)
            %  sig_z            6)
            %  sig_cs           7)
            %  sig_sb           8)
            %  sig_tx           9)

eta_cs   = xparam(1);
pphi     = xparam(2);
eta_SB   = xparam(3);
eta_tax  = xparam(4);
ro_z     = xparam(5);
sig_z    = xparam(6);
sig_cs   = xparam(7);
sig_sb   = xparam(8);
sig_tx   = xparam(9);

thta_wcap = 0.0;
estimated_parameters = [thta_wcap; eta_cs; pphi];
% -------------------------------------------------------------------------




%% save important stuff into temporary .xlsx files
% -------------------------------------------------------------------------
cd(ExcelFolder)
datamoments = data(rownr,6:25)';
csvwrite('data_moments.csv',datamoments);
if strcmp(preferences , 'CD') == 1
    csvwrite('preferences.csv',0);
elseif strcmp(preferences , 'GHH') == 1
    csvwrite('preferences.csv',1);
end
csvwrite('counterfactual.csv',counterfactual);
% -------------------------------------------------------------------------


%% calculate steady-state and initial guess
% -------------------------------------------------------------------------
cd(MatlabFolder)
xinput = -0.2*ones(2,1);
if counterfactual == 0 || counterfactual == 10
xinput = [xinput;0.03;0.049;0.02;0.04;-0.09;log(0.33); 0.12; 0.48];
elseif counterfactual == 1 || ...   % changing size of transfers
       counterfactual == 3 || ...   % changing size and cycle of transfers
       counterfactual == 4 || ...   % changing taxes
       counterfactual == 5 || ...   % changing taxes
       counterfactual == 9
xinput = [xinput;0.03;0.049;0.02;0.04;-0.09];
end
AMJR_compute_ststate;
calibrated_parameters = [dbar; bgbar; sbbar; gama; ...
    tauk; tauc; taul_rich; taul_poor];

chiR = chi;
chiP = chi;
% -------------------------------------------------------------------------


%% save calibration results to a separate file
% -------------------------------------------------------------------------
cd(ResultsFolder)
savefile = strcat(preferences,'_','counterfactualcalibration_',num2str(counterfactual),'.mat');
save(savefile);
% -------------------------------------------------------------------------

cd(DynareFolder)
%% save steady-state guess
% -------------------------------------------------------------------------
fid = fopen('ststate_guess.txt','wt+');
fprintf(fid,'y         = %8.8f; \n',log(Y));
fprintf(fid,'cagg      = %8.8f; \n',log(C));
fprintf(fid,'ellR      = %8.8f; \n',log(ellR));
fprintf(fid,'ellP      = %8.8f; \n',log(ellP));
fprintf(fid,'cR        = %8.8f; \n',log(cR));
fprintf(fid,'cP        = %8.8f; \n',log(cP));
fprintf(fid,'inv       = %8.8f; \n',log(I));
fprintf(fid,'nxy       = %8.8f; \n',NX/Y);
fprintf(fid,'k         = %8.8f; \n',log(K/NR));
fprintf(fid,'debt      = %8.8f; \n',dbar);
%fprintf(fid,'bgov      = %8.8f; \n',0.00);
%fprintf(fid,'tax_lump  = %8.8f; \n',log(TAX_LUMPSUM));
fprintf(fid,'z         = %8.8f; \n',0.0);
fprintf(fid,'g         = %8.8f; \n',mug);
fprintf(fid,'sb        = %8.8f; \n',log(sbbar));
fprintf(fid,'rmex      = %8.8f; \n',log(Rstar));
fprintf(fid,'r         = %8.8f; \n',log(Rstar));
fprintf(fid,'cs        = %8.8f; \n',0.0);
fprintf(fid,'t_hat     = %8.8f; \n',0.0);
fprintf(fid,'taxes     = %8.8f; \n',log(TAX_LABOR + TAX_CONS + TAX_CAPITAL));
fprintf(fid,'gama      = %8.8f; \n',log(gama));
fprintf(fid,'lshare    = %8.8f; \n',log(LSHARE));
fclose(fid);
% -------------------------------------------------------------------------


%% save deep parameters
% -------------------------------------------------------------------------
fid = fopen('deep_params.txt','wt+');
fprintf(fid,'@#define ghh   = %d  \n',GHH);
fprintf(fid,'@#define cd    = %d  \n',CD);
fprintf(fid,'@#define sep   = %d  \n',SEP);
fprintf(fid,'     \n' );
fprintf(fid,'     \n' );
fprintf(fid,'betta          = %6.6f; \n',betta);
fprintf(fid,'sgma           = %6.6f; \n',sgma);
fprintf(fid,'mug            = %6.6f; \n',mug);
fprintf(fid,'Rstar          = %6.6f; \n',Rstar);
fprintf(fid,'NR             = %6.6f; \n',NR);
fprintf(fid,'NP             = %6.6f; \n',NP);
fprintf(fid,'gamabar        = %6.6f; \n',gama);
fprintf(fid,'nuR            = %6.6f; \n',nuR);
fprintf(fid,'nuP            = %6.6f; \n',nuP);
fprintf(fid,'chi            = %6.6f; \n',chi);
fprintf(fid,'chiR           = %6.6f; \n',chiR);
fprintf(fid,'chiP           = %6.6f; \n',chiP);
fprintf(fid,'dlta           = %6.6f; \n',dlta);
fprintf(fid,'alfa           = %6.6f; \n',alfa);
fprintf(fid,'kapa           = %6.6f; \n',kapa);
fprintf(fid,'kapa_g         = %6.6f; \n',kapa_g);
fprintf(fid,'dbar           = %6.6f; \n',dbar);
fprintf(fid,'sbbar          = %6.6f; \n',sbbar);
fprintf(fid,'thta_wcap      = %6.6f; \n',thta_wcap);
fprintf(fid,'tauc           = %6.6f; \n',tauc);
fprintf(fid,'tauk           = %6.6f; \n',tauk);
fprintf(fid,'taul_poor      = %6.6f; \n',taul_poor);
fprintf(fid,'taul_rich      = %6.6f; \n',taul_rich);
fprintf(fid,'taxlbar        = %6.6f; \n',TAX_LUMPSUM);
fprintf(fid,'eta_cs         = %6.6f; \n',eta_cs);
fprintf(fid,'pphi           = %6.6f; \n',pphi);
fprintf(fid,'eta_sb         = %6.6f; \n',eta_SB);
fprintf(fid,'eta_tax        = %6.6f; \n',eta_tax);
fprintf(fid,'eta_gama       = %6.6f; \n',eta_gama);
fprintf(fid,'ro_z           = %6.6f; \n',ro_z);
fprintf(fid,'sig_z          = %6.6f; \n',sig_z);
fprintf(fid,'sig_cs         = %6.6f; \n',sig_cs);
fprintf(fid,'sig_s          = %6.6f; \n',sig_sb);
fprintf(fid,'sig_tx         = %6.6f; \n',sig_tx);
fprintf(fid,'ybar           = %6.6f; \n',log(Y));
fclose(fid);
% -------------------------------------------------------------------------



%% RUN DYNARE
% -------------------------------------------------------------------------
dynare RBC_distaxes_onesector
% -------------------------------------------------------------------------
options_.noprint = 1;



%% SET UP FOR THE COUNTER-FACTUAL SIMULATION

global data_moments moments_targeted cntry prefs estimation
cd excel_files
data_moments = csvread('data_moments.csv');
utility_function = csvread('preferences.csv');
scenario = csvread('counterfactual.csv');
if utility_function == 1
    prefs = 'GHH';
elseif utility_function == 0
    prefs = 'CD';
end


%% LOAD ESTIMATION RESULTS
% ----------------------------------------------------------
cd ..
cd results
loadfile = strcat(prefs,'_developed_estimation_v3.mat');
load(loadfile)
MODEL_DATA_DEVELOPED   = MODEL_DATA;
PARAM_ERRORS_DEVELOPED = PARAM_ERRORS;
clear PARAM_ERRORS
clear MODEL_DATA
loadfile = strcat(prefs,'_emerging_estimation_v3.mat');
load(loadfile)
MODEL_DATA_EMERGING   = MODEL_DATA;
PARAM_ERRORS_EMERGING = PARAM_ERRORS;


loadfile = strcat(prefs,'_','counterfactualcalibration_',num2str(scenario),'.mat');
load(loadfile,'calibrated_parameters','calibrated_parameters_emerging')
% ----------------------------------------------------------

if scenario == 10
    MODEL_DATA = MODEL_DATA_DEVELOPED;
end


%% results from AR(1) regression of r^USA, 
% where r^USA is interest on a 3-month T-bill 
% minus CPI inflation in the U.S.
% ----------------------------------------------
global roR sig_r
sdevR = .0229;
varR = sdevR^2;
roR = 0.8107;
sig_r = varR*(1-roR^2);
sig_r = sig_r^0.5;
% ----------------------------------------------




%% SIMULATE COUNTER-FACTUAL
% ----------------------------------------------------------




%% counter-factuals
% ----------------------------------------------
% 1 - benefits: size
% 2 - benefits: cyclicality
% 3 - benefits: size and cyclicality
% 4 - taxes: size and cyclicality
% 5 - benefits and taxes
% 6 - inequality: wealth
% 7 - inequality: income
% 8 - inquality both
% 9 - inequality, benefits, and taxes
% ----------------------------------------------


%% parameter indices
% ----------------------------------------------
% xparam = [    \eta_cs          1)
%               inv adj cost     2)
%               eta_sb           3)
%               eta_tx           4)
%               rho_z            5)
%               sig_z            6)
%               sig_cs           7)
%               sig_sb           8)
%               sig_tx           9)
% ----------------------------------------------



if scenario ~= 10
    xparam = PARAM_ERRORS_EMERGING(:,1);            % any counterfactual and/or re-simulating emerging moments
else
    xparam = PARAM_ERRORS_DEVELOPED(:,1);           % re-simulating developed moments
end
xparam_developed = PARAM_ERRORS_DEVELOPED(:,1);     % vector of parameters for a developed country


% replace selected estimated parameters depending on the counterfactual
% ---------------------------------------------------------------------------
if scenario == 2                                % benefits cycle
    indeksy = [3];
elseif scenario == 3                                % benefits size and cycle
    indeksy = [3];
elseif scenario == 4                            % taxes size and cycle
    indeksy = [4];
elseif scenario == 5                            % fiscal policy = benefits and taxes, size and cycle
    indeksy = [3;4];
elseif scenario == 7 || scenario == 8           % inequality
    indeksy = [];
elseif scenario == 5 || scenario == 9           % inequality + fiscal policy
    indeksy = [3;4];
else
    indeksy = [];                               % all other
end
xparam(indeksy,1) = xparam_developed(indeksy,1);
% ---------------------------------------------------------------------------




% quadratic trend
% ----------------------------------------------------------
global XX1
time_trend  = [1:1:500]';
XX1 = [ones(length(time_trend),1), time_trend, time_trend.^2];
% ----------------------------------------------------------


% simulation parameters
% ----------------------------------------------------------
global nperiods replications shocks burnin 
nperiods = 250;             % T = 2000
burnin   = nperiods - 200;  % T = 1500 after we drop initial 500
replications = 2000;         % N = 2000
randn('seed', 1);
shocks = randn(nperiods,M_.exo_nbr,replications);
% ----------------------------------------------------------


cd ..
cd matlab_files

%
disp(' ')
disp(' simulating counter-factual ')

disp(' ')
estimation = 1;
disp('computing variance-covariance of models and parameters')
[mmts2, vcv_mtrix] = AMJR_smm_objective_annual(xparam);
MODEL_COUNTER   = [mmts2 sqrt(diag(vcv_mtrix))];

disp(' ')
disp(' results of the counterfactual: [counterfactual, (s.e.), data]') 
disp('-------------------------------------------------------------------')
disp([MODEL_COUNTER MODEL_DATA(:,3)])
disp('-------------------------------------------------------------------')
disp(' ')

disp(' ')
disp('most recent scenario number was')
disp('-------------------------------------------------------------------')
disp(scenario)
disp('-------------------------------------------------------------------')
disp(' ')

disp(' ')
disp(' modified vs. original parameters from estimation') 
disp('-------------------------------------------------------------------')
disp([xparam PARAM_ERRORS_EMERGING(:,1)]')
disp('-------------------------------------------------------------------')
disp(' ')

disp(' ')
disp(' modified vs. original parameters from calibration') 
disp('-------------------------------------------------------------------')
disp([calibrated_parameters calibrated_parameters_emerging]')
disp('-------------------------------------------------------------------')
disp(' ')
% 

cd ..
cd results

MODEL_DATA1 = MODEL_DATA;
loadfile = strcat(prefs,'_','counterfactualcalibration_',num2str(scenario),'.mat');
load(loadfile);
MODEL_DATA = MODEL_DATA1;


savefile = strcat(prefs,'_counterfactual_',num2str(scenario),'.mat');
save(savefile,'PARAM_ERRORS_EMERGING','PARAM_ERRORS_DEVELOPED','MODEL_DATA_EMERGING','MODEL_DATA_DEVELOPED','MODEL_COUNTER','xparam','xparam_developed','calibrated_parameters');

cd ..
cd matlab_files
