function YY = simulate_dynareseries(oo_,shock_matrix)

       AA  = oo_.dr.ghx;
       BB  = oo_.dr.ghu;
       ys  = oo_.dr.ys;
       
       TT = size(shock_matrix,2);
       YY = repmat(ys,1,TT);
       
       yt = ys(oo_.dr.order_var) + BB*shock_matrix(:,1);
       yt = yt(oo_.dr.inv_order_var);
       YY(:,1) = yt;
       
       for t = 2:TT
           yt1 = yt;
           yt  = ys(oo_.dr.order_var) + AA*(yt1(oo_.dr.state_var') - ys(oo_.dr.state_var')) ...
               + BB*shock_matrix(:,t);
           yt = yt(oo_.dr.inv_order_var);
           YY(:,t) = yt;
       end

end

