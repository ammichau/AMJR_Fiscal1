%% ______________________ MAIN REPLICATION FILE FOR: ______________________
% Michaud and Rothert (2018), "Redistributive Policies and Business Cycles 
% in Emerging Economies", Journal of International Economics
% (c) J.Rothert, USNA, 2018
%
% AMJR_jie2018_main.m
%   - calls: 
%       a) Inequality_Targets.xlsx (excel file with data stats 
%                                   for calibration and estimation targets)
%       b) AMJR_compute_ststate.m, 
%                       which in turn calls AMJR_distaxes_ststate.m
%       c) RBC_distaxes_onesector.mod (Dynare file for solving the model 
%                                       and computing model decision rules) 
%       d) AMJR_smm_objective_annual.m (m-file that computes model moments 
%                                           and \sum(model-data)^2)
%   - major output: 
%       a) calibrated parameters
%       b) estimated parameters and their standard errors
%   - major output saved in (if GHH preferences):
%       a) GHH_emerging_estimation_v3.mat, GHH_developed_estimation_v3.mat
%          GHH_emerging_calibration.mat, GHH_developed_calibration.mat
%
%   - you will need to run this file twice:
%           once setting country = 'emerging', 
%           then setting country = 'developed' in line 81
%
% -------------------------------------------------------------------------

%%
clear all
clc

%% ____________________________ specify paths ____________________________
% ADD DYNARE PATH
addpath C:\dynare\4.4.3\matlab

% SPECIFY THE MAIN PATH TO THE PROJECT'S PARENT DIRECTORY
mainpath = 'C:\Users\rothert\Dropbox\work\research\ZZZ_PUBLISHED\05_JIE2018_RedistributivePolicies\replication_files\';

% DEFINE SUBFOLDERS
ExcelFolder   =  strcat(mainpath,'excel_files');
MatlabFolder  =  strcat(mainpath,'matlab_files');
ResultsFolder =  strcat(mainpath,'results');
DynareFolder  =  mainpath;
% -------------------------------------------------------------------------

%% global variables
global preferences
global country rownr
global deep_parameters
global COUNTRY_MOMENTS
global estimated_parameters
global tauk tauc taul_rich taul_poor
global bgbar sbbar dbar gama
global calibrated_parameters
global counterfactual
counterfactual = 0;
%% preferences
% ------------------------------------------------------------------------
preferences = 'GHH';
GHH = 0; CD  = 0; SEP = 0;
nuR = 0.60; nuP = nuR;
% 'GHH' or 'CD' or 'separable'
if  strcmp(preferences , 'GHH') == 1
    GHH = 1;
    chi = 1.45;
elseif strcmp(preferences , 'CD') == 1
    CD  = 1;
    chi = 0.60;
elseif strcmp(preferences , 'separable') == 1
    SEP = 1;
    chi = 1.00;
end
chiR = chi;
chiP = chi;
% ------------------------------------------------------------------------


%% country and rownr
% ------------------------------------------------------------------------
country = 'emerging';
rownr = 1*strcmp(country,'emerging') + 2*strcmp(country,'developed');
% ------------------------------------------------------------------------


%% deep parameters
% ------------------------------------------------------------------------
betta  = 0.96;      % discount (annual)
sgma   = 2.0000;    % IES
mug    = 0.00;      % balanced growth rate (annual)
dlta   = 0.04;      % depreciation
alfa   = 0.33;      % capital share
kapa   = 0.001;     % portfolio adj cost private
kapa_g = 0.001;     % portfolio adj cost govt
% world interest rate
if strcmp(preferences , 'CD') == 1
    Rstar = 1.0/betta * exp(mug)^(1-chi*(1-sgma));
else
    Rstar = 1.0/betta * exp(mug)^sgma;
end
deep_parameters = [betta; sgma; mug; dlta; alfa; Rstar; kapa; kapa_g; ...
    GHH; CD; SEP; ...
    nuR; nuP; chi; chiR; chiP];

% pre-defined shock parameters
ro_z     =  0.80;
eta_gama =  0.00;
sig_z    =  0.01;
sig_cs   =  0.04;
sig_sb   =  0.01;
sig_tx   =  0.01;
% ------------------------------------------------------------------------


%% COUNTRY MOMENTS
% -------------------------------------------------------------------------
cd(ExcelFolder)
data  = xlsread('InequalityTargets.xlsx','data_inputs');

NR          = data(rownr,1);
INCSHARE    = data(rownr,2);
INT_GDP     = data(rownr,3);
SBEN_GDP    = data(rownr,4);
DEBT_GDP    = data(rownr,5);
NP          = 1.00 - NR;
eta_SB      = -3.77; %*(emerging==0);
eta_tax     = 0.00;
VATperc     = data(rownr,size(data,2)-3);
PITperc     = data(rownr,size(data,2)-2);
CITperc     = data(rownr,size(data,2)-1);
PITE        = data(rownr,size(data,2));

COUNTRY_MOMENTS = [NR; INCSHARE; INT_GDP; SBEN_GDP; DEBT_GDP; NP;...
    VATperc; PITperc; CITperc; PITE];
% -------------------------------------------------------------------------




%% estimated_parameters
% -------------------------------------------------------------------------
thta_wcap = 0.0;
eta_cs = 0.0;
pphi = 1.0;
estimated_parameters = [thta_wcap; eta_cs; pphi];
% -------------------------------------------------------------------------




%% save datamoments to a temporary .xlsx file
% -------------------------------------------------------------------------
datamoments = data(rownr,6:25)';
xlswrite('data_moments.xlsx',datamoments);
if strcmp(preferences , 'CD') == 1
    xlswrite('preferences.xlsx',0);
elseif strcmp(preferences , 'GHH') == 1
    xlswrite('preferences.xlsx',1);
end
% -------------------------------------------------------------------------


%% calculate steady-state and initial guess
% -------------------------------------------------------------------------
cd(MatlabFolder)
xinput = -0.2*ones(10,1);
AMJR_compute_ststate;
xinput = xin;
calibrated_parameters = [dbar; bgbar; sbbar; gama; ...
    tauk; tauc; taul_rich; taul_poor];
% -------------------------------------------------------------------------


%% save calibration results to a separate file
% -------------------------------------------------------------------------
cd(ResultsFolder)
savefile = strcat(preferences,'_',country,'_calibration.mat');
save(savefile,'calibrated_parameters','preferences','xinput');
% -------------------------------------------------------------------------



%% save steady-state guess and parameteres into Dynare folder
% -------------------------------------------------------------------------
cd(DynareFolder)
% save steady-state guess
% -------------------------------------------------------------------------
fid = fopen('ststate_guess.txt','wt+');
fprintf(fid,'y         = %8.8f; \n',log(Y));
fprintf(fid,'cagg      = %8.8f; \n',log(C));
fprintf(fid,'ellR      = %8.8f; \n',log(ellR));
fprintf(fid,'ellP      = %8.8f; \n',log(ellP));
fprintf(fid,'cR        = %8.8f; \n',log(cR));
fprintf(fid,'cP        = %8.8f; \n',log(cP));
fprintf(fid,'inv       = %8.8f; \n',log(I));
fprintf(fid,'nxy       = %8.8f; \n',NX/Y);
fprintf(fid,'k         = %8.8f; \n',log(K/NR));
fprintf(fid,'debt      = %8.8f; \n',dbar);
fprintf(fid,'z         = %8.8f; \n',0.0);
fprintf(fid,'g         = %8.8f; \n',mug);
fprintf(fid,'sb        = %8.8f; \n',log(sbbar));
fprintf(fid,'rmex      = %8.8f; \n',log(Rstar));
fprintf(fid,'r         = %8.8f; \n',log(Rstar));
fprintf(fid,'cs        = %8.8f; \n',0.0);
fprintf(fid,'t_hat     = %8.8f; \n',0.0);
fprintf(fid,'taxes     = %8.8f; \n',log(TAX_LABOR + TAX_CONS + TAX_CAPITAL));
fprintf(fid,'gama      = %8.8f; \n',log(gama));
fprintf(fid,'lshare    = %8.8f; \n',log(LSHARE));
fclose(fid);
% -------------------------------------------------------------------------

% save parameters
% -------------------------------------------------------------------------
fid = fopen('deep_params.txt','wt+');
fprintf(fid,'@#define ghh   = %d  \n',GHH);
fprintf(fid,'@#define cd    = %d  \n',CD);
fprintf(fid,'@#define sep   = %d  \n',SEP);
fprintf(fid,'     \n' );
fprintf(fid,'     \n' );
fprintf(fid,'betta          = %6.6f; \n',betta);
fprintf(fid,'sgma           = %6.6f; \n',sgma);
fprintf(fid,'mug            = %6.6f; \n',mug);
fprintf(fid,'Rstar          = %6.6f; \n',Rstar);
fprintf(fid,'NR             = %6.6f; \n',NR);
fprintf(fid,'NP             = %6.6f; \n',NP);
fprintf(fid,'gamabar        = %6.6f; \n',gama);
fprintf(fid,'nuR            = %6.6f; \n',nuR);
fprintf(fid,'nuP            = %6.6f; \n',nuP);
fprintf(fid,'chi            = %6.6f; \n',chi);
fprintf(fid,'chiR           = %6.6f; \n',chiR);
fprintf(fid,'chiP           = %6.6f; \n',chiP);
fprintf(fid,'dlta           = %6.6f; \n',dlta);
fprintf(fid,'alfa           = %6.6f; \n',alfa);
fprintf(fid,'kapa           = %6.6f; \n',kapa);
fprintf(fid,'kapa_g         = %6.6f; \n',kapa_g);
fprintf(fid,'dbar           = %6.6f; \n',dbar);
fprintf(fid,'sbbar          = %6.6f; \n',sbbar);
fprintf(fid,'thta_wcap      = %6.6f; \n',thta_wcap);
fprintf(fid,'tauc           = %6.6f; \n',tauc);
fprintf(fid,'tauk           = %6.6f; \n',tauk);
fprintf(fid,'taul_poor      = %6.6f; \n',taul_poor);
fprintf(fid,'taul_rich      = %6.6f; \n',taul_rich);
fprintf(fid,'taxlbar        = %6.6f; \n',TAX_LUMPSUM);
fprintf(fid,'eta_cs         = %6.6f; \n',eta_cs);
fprintf(fid,'pphi           = %6.6f; \n',pphi);
fprintf(fid,'eta_sb         = %6.6f; \n',eta_SB);
fprintf(fid,'eta_tax        = %6.6f; \n',eta_tax);
fprintf(fid,'eta_gama       = %6.6f; \n',eta_gama);
fprintf(fid,'ro_z           = %6.6f; \n',ro_z);
fprintf(fid,'sig_z          = %6.6f; \n',sig_z);
fprintf(fid,'sig_cs         = %6.6f; \n',sig_cs);
fprintf(fid,'sig_s          = %6.6f; \n',sig_sb);
fprintf(fid,'sig_tx         = %6.6f; \n',sig_tx);
fprintf(fid,'ybar           = %6.6f; \n',log(Y));
fclose(fid);
% -------------------------------------------------------------------------





%% RUN DYNARE
% -------------------------------------------------------------------------
dynare RBC_distaxes_onesector
% -------------------------------------------------------------------------





%% SET UP FOR THE ESTIMATION
global data_moments moments_targeted cntry
cd excel_files
data_moments = xlsread('data_moments.xlsx');
utility_function = xlsread('preferences.xlsx');
if utility_function == 1
    prefs = 'GHH';
elseif utility_function == 0
    prefs = 'CD';
end
cd ..
cd matlab_files

moments_targeted = [5;   % sdev(Y)
                    6;   % sdev(c) / sdev(y)
                    7;   % sdev(inv) / sdev(y)
                    1;   % sdev(benefits) / sdev(y)
                    2;   % sdev(revenues) / sdev(y)
                    9;   % sdev(R)
                    3;   % rho(ben,gdp)
                    4;   % rho(tax,gdp)
                    12;  % rho(nx,gdp)
                    13;  % rho(r,gdp)
                    14;  % rho(y,y(-1))
                    10;  % rho(c,gdp)           % will not be targeted in the end 
                    11]; % rho(x,gdp)           % will not be targeted in the end 


if data_moments (6) > 1
    cntry = 'emerging';
else
    cntry = 'developed';
end

                
                
global nperiods replications shocks burnin estimation
nperiods = 250;
burnin   = nperiods - 200;
replications = 3;
randn('seed', 1);
shocks = randn(nperiods,M_.exo_nbr,replications);

global roR sig_r
%% results from AR(1) regression of r^USA
sdevR = .0229;
varR = sdevR^2;
roR = 0.8107;
sig_r = varR*(1-roR^2);
sig_r = sig_r^0.5;


options = optimset('Display','iter');

estimation = 2;
% set lower bound
lbd = [...
    -5.001;        % \eta_cs
    0.00001;       % inv adj cost
    -10;            % eta_sb
    -10;            % eta_tx
    0.00;          % rho_z
    0.00001;       % sig_z
    0.00001;       % sig_cs
    0.00001;       % sig_sb
    0.00001];      % sig_tx

% set upper bound
ubd = [ ... %1; % wcapital
    1.001;      % eta_cs
    100.0000;   % pphi
    10;          % eta_sb
    10;          % eta_tx
    0.95;       % rho_z
    0.95;       % sig_z
    0.95;       % sig_cs
    0.95;       % sig_sb
    0.95];      % sig_tx


if strcmp(cntry, 'emerging') == 1
 % initial guess
x0 = [ ... %0.001; % wcapital
    -2.5000;  % eta_cs
    20.9879;     % pphi
    1.970959;     % eta_sb
    0.2581;     % eta_tx
    0.7100;     % rho_z
    0.0135;     % sig_z
    0.00081;     % sig_cs
    0.0045;     % sig_sb
    0.0006];    % sig_tx   
elseif strcmp(cntry, 'developed') == 1
 % initial guess
x0 = [ ... %0.001; % wcapital
    -0.000;  % eta_cs
    20.9879;     % pphi
    -1.970959;     % eta_sb
    -0.2581;     % eta_tx
    0.7100;     % rho_z
    0.0135;     % sig_z
    0.00081;     % sig_cs
    0.0045;     % sig_sb
    0.0006];    % sig_tx   
end


if size(ubd) ~= size(lbd)
    warning('sth wrong with upper and lower bounds for initial guess')
    return;
end
if size(ubd) ~= size(x0)
    warning('sth wrong with bounds and the initial guess')
    return;
end




global XX1
time_trend  = [1:1:500]';
XX1 = [ones(length(time_trend),1), time_trend, time_trend.^2];


% get us closer to the solution with fewer replications
x00 = fmincon('AMJR_smm_objective_annual',x0,[],[],[],[],lbd,ubd,[],options);



%% RUN THE FULL ESTIMATION
% ------------------------------------------------------------------------------
% set number of replications
replications = 2000;
nperiods = 250;
burnin   = nperiods - 200;
randn('seed', 1);
shocks = randn(nperiods,M_.exo_nbr,replications);
tic
x00 = fmincon('AMJR_smm_objective_annual',x00,[],[],[],[],lbd,ubd,[],options);
toc
% ------------------------------------------------------------------------------


%% COMPUTE STANDARD ERRORS OF MODEL PARAMETERS
% ------------------------------------------------------------------------------
nperiods = 250;
burnin   = nperiods - 200;
replications = 2000;
randn('seed', 1);
shocks = randn(nperiods,M_.exo_nbr,replications);

estimation = 1;
mmts_model = AMJR_smm_objective_annual(x00);
dmdth = Df('AMJR_smm_objective_annual',x00);            % JACOBIAN

replications = 2000;
randn('seed', 1);
shocks = randn(nperiods,M_.exo_nbr,replications);

estimation = 1;
disp('computing variance-covariance of models and parameters')
[mmts, vcv_mtrix] = AMJR_smm_objective_annual(x00);                 % V-COV OF MODEL MOMENTS
VCVparam = (1+1/replications)*(dmdth'*vcv_mtrix^(-1)*dmdth)^(-1);   % V-COV OF MODEL PARAMETERES
p_errors = sqrt(diag(VCVparam));                                    % (S.E.) OF MODEL PARAMETERS
% ------------------------------------------------------------------------------



%% SAVE ESTIMATION RESULTS
% ------------------------------------------------------------------------------
PARAM_ERRORS = [x00 p_errors];
MODEL_DATA   = [mmts sqrt(diag(vcv_mtrix)) data_moments(moments_targeted)];
savefile = strcat(prefs,'_',cntry,'_estimation_v3.mat');
cd ..
cd results
save(savefile,'PARAM_ERRORS','MODEL_DATA','moments_targeted')
format('SHORT')
disp(PARAM_ERRORS)
disp(MODEL_DATA)
% ------------------------------------------------------------------------------

